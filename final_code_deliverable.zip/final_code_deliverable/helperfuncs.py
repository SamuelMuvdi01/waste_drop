def capitalize(arg):
    return arg[0].upper() + arg[1:]